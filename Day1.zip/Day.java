

import java.util.Scanner;

public class Day {

	public static void main(String[] args) {{
		System.out.print("Enter Your Name");
	}
		Scanner na = new Scanner(System.in);
		String a = na.next();
		    {
			
			System.out.println(a);
		}
		Scanner sc = new Scanner(System.in);{
		System.out.print("Enter value:");
		}
		int n = sc.nextInt();
		if(n>=1)
		    for (int i= 1;i<=10;i++) {
			System.out.println(i+"x"+n+"="+i*n);
		}
		else {
			System.out.print("Enter num   ber only");
		}
	
	}
	

}
