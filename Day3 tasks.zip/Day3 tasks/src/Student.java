
public class Student {
	 
	int Id;
	String name ;
	static String dep;
	double cgp;
	static String clgName;
	 
	static {
		  clgName="MAM College of engineering";	
	      dep ="CSE";
	}
	
	Student(int Id,	String name,double cgp){
		
		this.Id=Id;
		this.name=name;
		this.cgp=cgp;
	}

	Student(int Id){
		this.Id=Id;
	}
	Student (String name){
		this.name=name;
	}
	Student(double cgp){
		this.cgp=cgp;
	}
	
    public String toString() {
    	return Id +" " +name+" "+cgp+" "+dep+" "+clgName  ;
    }
}
