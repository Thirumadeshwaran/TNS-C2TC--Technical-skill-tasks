
public class Employee {
	String name;  
	int id ;
	int salary ;
	
	Employee(String name,int id,int salary){
		
		this.name =name;
		this.id=id;
		this.salary=salary;
		 
	}
	public String toString()
	{
		return(name+" "+id+" "+salary);
	}
	

}
