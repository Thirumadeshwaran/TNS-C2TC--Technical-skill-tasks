import java.util.Scanner;

public class BankAcc {
		public void acc(){
		 
		int acc =1;
		String name ="Aathi" ;
		double bal=101305565;
		
		System.out.println("Account No:"+acc);
		System.out.println("Name :"+name);
		System.out.println("Balance:"+bal);
		
		}
	public void acc2(){
		
	int acc =2;
	String name ="srimath" ;
	double bal=220000;
	
	System.out.println("Account No:"+acc);
	System.out.println("Name :"+name);
	System.out.println("Balance:"+bal);
	}
}

