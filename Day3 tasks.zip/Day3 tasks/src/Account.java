import java.util.Scanner;
public class Account {
		public static void main(String[] args) {
			
	
		System.out.print("Enter your Account Number:");
		Scanner a = new Scanner(System.in);
		int acc =a.nextInt(); 	
 {
	if(acc==1) {	
		BankAcc BankAccObject = new BankAcc();
		BankAccObject.acc();
		}
		
	else if(acc==2 ){
		BankAcc BankAccObject = new BankAcc();
		BankAccObject.acc2();
	}	
		else  {
			System.out.println("N0 Account");
			System.out.println("Check the Account number");
		}
	}
  }
}