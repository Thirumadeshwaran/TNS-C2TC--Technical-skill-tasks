
public class Info {

	public static void main(String[] args) {
		{	
		Student s1 = new Student (101,"madesh",7.7);
		Student s2 = new Student (102,"thina",9.5);
		Student s3 = new Student (103,"varun",8.7);
		Student s4 = new Student (104,"saran",8.6);
		Student s5 = new Student (105,"srimath",9.9);
		{
			{
				System.out.println("Student Info:");
				System.out.println("Id " + " Name"+" Cgp"+" Dep"+"  College");
			}
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		System.out.println(s4);
		System.out.println(s5);
		
		}
		} 
	System.out.println("===============");
		{
	  Employee e1 = new Employee("hari",201,20000);
	  Employee e2 = new Employee("fazal",202,25000);
	  Employee e3 = new Employee("karthi",203,30000);
	  Employee e4 = new Employee("umar",204,50000);

   {
	   {
			System.out.println("Empolyee Info:");
			System.out.println("Name "+"Id"+" Salary");
		}
	
	System.out.println(e1);
	System.out.println(e2);
	System.out.println(e3);
	System.out.println(e4);
     } 
   }
		System.out.println("===============");
  }
 }

