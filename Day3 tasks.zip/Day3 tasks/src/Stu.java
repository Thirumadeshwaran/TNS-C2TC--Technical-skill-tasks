
public class Stu {
       int id;
       String name;
       int age;
       
       Stu(int id,String name,int age){
			this.id=id;
			this.name=name;
			this.age=age;
       }
		public void s1(int id,String name,int age) {
	    {
	    	System.out.println("ID:"+id);
	    	System.out.println("Name:"+name);
	    	System.out.println("Age:"+age);
		
		}
       
		}}

	


