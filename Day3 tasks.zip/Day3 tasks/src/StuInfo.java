import java.util.Scanner;
public class StuInfo {

	public static void main(String[] args) {
		{
		System.out.print("Enter Student Id:");	
		Scanner a = new Scanner(System.in);
		 int id = a.nextInt();
		
		if(id==1){	
		Stu StuObjet = new Stu(1,"Rokesh", 20);
		StuObjet.s1(1,"rokesh",20);}
		else if(id==2){	
			Stu StuObjet = new Stu(2,"balu",21);
			StuObjet.s1(2,"balu",21);}
		else if(id==3){	
			Stu StuObjet = new Stu(3,"pushapa", 25);
			StuObjet.s1(3,"thina", 21);}
		else if(id==4){	
			Stu StuObjet = new Stu(4,"sabeer", 18);
			StuObjet.s1(4,"sabeer", 18);}
		else {
			System.out.print("Check the Student Id");
			
		}
	  }
	}
  }

	
