
// BonusPoints.java

public interface BonusPoints {
    double calculateBonusPoints();
}