// DoorDelivery.java

public interface DoorDelivery {
    double deliveryCharge();
}