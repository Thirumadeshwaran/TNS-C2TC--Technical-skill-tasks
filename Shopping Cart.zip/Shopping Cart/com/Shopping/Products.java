package com.Shopping;
import java.util.*;

public class Products {
    private List<String> productList;

    public Products() {
        productList = new ArrayList<>();
    }
    public List<String> getProductList() {
        return productList;
    }
    public void setProductList(List<String> productList) {
        this.productList = productList;
    }
    public void addProductToList(String product) {
        productList.add(product);
    }
        public void sortProductList() {
        Collections.sort(productList);
    }

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
			Products shoppingCart = new Products();

			while (true) {
			    System.out.println("\nMenu:");
			    System.out.println("1. Add product");
			    System.out.println("2. Display products in alphabetical order");
			    System.out.println("3. Exit");
			    System.out.print("Enter your choice (1-3): ");
			    int choice = scanner.nextInt();
			    scanner.nextLine(); 

			    switch (choice) {
			        case 1:
			            System.out.print("Enter product name: ");
			            String product = scanner.nextLine();
			            shoppingCart.addProductToList(product);
			            System.out.println("Product added to the cart.");
			            break;
			        case 2:
			            if (shoppingCart.getProductList().isEmpty()) {
			                System.out.println("The list is empty.");
			            } else {
			                shoppingCart.sortProductList();
			                System.out.println("Products in alphabetical order:");
			                for (String item : shoppingCart.getProductList()) {
			                    System.out.println(item);
			                }
			            }
			            break;
			        case 3:
			            System.out.println("Thank you for using the application.");
			            System.exit(0);
			        default:
			            System.out.println("Invalid choice. Please select 1, 2, or 3.");
			    }
			}
		}
    }
}
